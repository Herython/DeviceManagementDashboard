document.addEventListener('DOMContentLoaded', function(){

    //reboot form post
    document.getElementById('rebootForm').addEventListener('submit', function(event){
        event.preventDefault();
        var deviceNumsReboot = [document.getElementById('deviceNumsReboot').value];
        var rightNowReboot = document.getElementById('rightNowReboot').checked;
        var data = {
            deviceNums: deviceNumsReboot,
            rightNow: rightNowReboot
        };
        sendPostRequest('/reboot', data, 'rebootResult')
    });

    //update form post
    document.getElementById('updataForm').addEventListener('submit', function(event){
        event.preventDefault();
        var deviceNumsUpdate = [document.getElementById('deviceNumsUpdate').value]; 
        var deviceTypeUpdate = document.getElementById('deviceTypeUpdate').value;
        var devicePowerUpdate = parseInt(document.getElementById('devicePowerUpdate').value, 10);
        var hostUpdate = document.getElementById('hostUpdate').value;
        var portUpdate = parseInt(document.getElementById('portUpdate').value, 10);
        var userNameUpdate = document.getElementById('userNameUpdate').value;
        var passwordUpdate = document.getElementById('passwordUpdate').value;
        var filePatternUpdate = document.getElementById('filePatternUpdate').value;
        var timeoutUpdate = parseInt(document.getElementById('timeoutUpdate').value, 10);
        var rightNowUpdate = document.getElementById('rightNowUpdate').checked;
        var data = {
            deviceNums: deviceNumsUpdate,
            deviceType: parseInt(deviceTypeUpdate, 10),
            devicePower: devicePowerUpdate,
            host: hostUpdate,
            port: portUpdate,
            userName: userNameUpdate,
            password: passwordUpdate,
            filePattern: filePatternUpdate,
            timeout: timeoutUpdate,
            rightNow: rightNowUpdate
        };
        sendPostRequest('/update', data, 'updateResult');
    });

    //changeServer form post
    document.getElementById('changeServerForm').addEventListener('submit', function(event) {
        event.preventDefault();
        var deviceNumsChangeServer = [document.getElementById('deviceNumsChangeServer').value]; 
        var hostChangeServer = document.getElementById('hostChangeServer').value;
        var portChangeServer = parseInt(document.getElementById('portChangeServer').value, 10);
        var data = {
            deviceNums: deviceNumsChangeServer,
            host: hostChangeServer,
            port: portChangeServer
        };
        sendPostRequest('/changeServer', data, 'changeServerResult');
    });

    //global post
    function sendPostRequest(endpoint, data, resultElementId){
        var baseUrl = 'http://192.168.8.120:17000'
        fetch(baseUrl + endpoint,{
            method: 'POST',
            headers: {
                'Content-Type':'application/json',
            },
            body: JSON.stringify(data)
        })

        .then(function(response){
            if(!response.ok){
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })

        .then(function(data){
            console.log('Success',data);
            document.getElementById(resultElementId).textContent = JSON.stringify(data, null, 2);
        })

        .catch(function(error){
            console.error('Error:', error);
            document.getElementById(resultElementId).textContent = 'Manipulate Error: ' + error.message;
        });
    }
});